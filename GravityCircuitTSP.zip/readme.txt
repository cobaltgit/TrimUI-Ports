1. Unzip me into the root of your TSP's SD card
2. Extract GravityCircuit.exe from your copy of Gravity Circuit with 7zip and place the contents into Data/ports/gravitycircuit/gamedata
3. Launch and enjoy!

Credit to u/PARANOIAH for launch script modifications