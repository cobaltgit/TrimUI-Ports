You will need to provide your own Data.rsdk file.

Built using the Linux instructions on ArkOS (10/02/2022 MD5:686DAA6B33F6E3EBF5E531193C23DB6D) on Anbernic RG353V.

Source at time of build: https://github.com/TheGammaSqueeze/RSDKv5-Decompilation
ArkOS Kernel Headers/Dev Mode enable: https://github.com/christianhaitian/arkos/tree/main/Headers

Credits for assisting with PortMaster packaging:
romadu
christianhaitian
