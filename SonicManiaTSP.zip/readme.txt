1. Unzip me into the root of your TSP's SD card
2. Add your Sonic Mania Data.rsdk to Data/ports/sonicmania
3. Launch and enjoy!